# Sistema de Perfil de Usuario y Cambio de Contraseña con PHP y MySQL

## Descripción

Este proyecto corresponde a la actividad del foro **Sistema de Perfil de Usuario y Cambio de Contraseña con PHP y MySQL**.

El sistema permite registrar usuarios, iniciar sesión, acceder a una zona privada de perfil, actualizar datos básicos, cambiar la contraseña de forma segura y cerrar sesión.

## Funcionalidades

- Registro de usuario con cédula, nombre, correo y contraseña.
- Validación de correo repetido.
- Almacenamiento seguro de contraseña con `password_hash`.
- Login con correo y contraseña.
- Verificación de contraseña con `password_verify`.
- Manejo de sesión con `$_SESSION`.
- Protección de páginas privadas.
- Actualización de nombre y correo.
- Cambio de contraseña verificando la contraseña actual.
- Cierre de sesión mediante `logout.php`.

## Requisitos

- PHP 8 o superior.
- MySQL o MariaDB.
- Servidor local como XAMPP, WAMP, Laragon o MAMP.
- Navegador web.
- phpMyAdmin o consola MySQL.

## Instalación local

1. Copiar la carpeta del proyecto en el directorio público del servidor local.
   Ejemplo genérico:

   ```txt
   ruta/del/servidor/proyecto
   ```

2. Iniciar Apache y MySQL desde el panel de XAMPP.

3. Abrir phpMyAdmin e importar el archivo:

   ```txt
   database.sql
   ```

4. Revisar los datos de conexión en:

   ```txt
   config/database.php
   ```

   Por defecto está configurado así:

   ```php
   $host = "localhost";
   $dbname = "perfil_usuario";
   $user = "root";
   $password = "";
   ```

5. Abrir el proyecto en el navegador:

   ```txt
   http://localhost/nombre-del-proyecto/
   ```

## Estructura del proyecto

```txt
proyecto/
│
├── assets/
│   └── css/
│       └── style.css
│
├── config/
│   └── database.php
│
├── includes/
│   ├── auth.php
│   ├── header.php
│   └── footer.php
│
├── cambiar_password.php
├── database.sql
├── index.php
├── login.php
├── logout.php
├── perfil.php
├── register.php
└── README.md
```

## Seguridad aplicada

El sistema aplica medidas básicas de seguridad:

- Las contraseñas no se guardan en texto plano.
- Se usa `password_hash` para crear el hash de la contraseña.
- Se usa `password_verify` para comprobar la contraseña ingresada.
- Las consultas a la base de datos se realizan con PDO y sentencias preparadas.
- Las páginas privadas verifican que exista una sesión activa.
- Se usa `session_regenerate_id(true)` al iniciar sesión correctamente.
- Se validan campos obligatorios y formato de correo.
- Se escapan los datos mostrados con `htmlspecialchars`.

## Flujo de prueba recomendado

1. Registrar un usuario nuevo.
2. Iniciar sesión con correo y contraseña.
3. Entrar al perfil.
4. Actualizar nombre o correo.
5. Cambiar la contraseña.
6. Cerrar sesión.
7. Probar el login con la nueva contraseña.
